package com.example.masterfood;

import android.widget.ImageView;

public class Cardapio {
    private ImageView imagem;
    private String comida, preco;


    Cardapio(ImageView imagem, String comida, String preco){
        this.imagem = imagem;
        this.comida = comida;
        this.preco = preco;
    }
    public ImageView getImagem(){return this.imagem;}
    public String getComida(){return this.comida;}
    public String getPreco(){return this.preco;}

}