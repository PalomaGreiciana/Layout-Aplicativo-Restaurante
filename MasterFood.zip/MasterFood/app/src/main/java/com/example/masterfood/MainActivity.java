package com.example.masterfood;

import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity {

    ArrayList<Cardapio> dadosCardapio;
    RecyclerView recyclerView;
    CardapioAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dadosCardapio = new ArrayList<>();

        Cardapio c1 = new Cardapio("@drawable/tortadetomate", "Torta de Tomate", "R$18,00");
        dadosCardapio.add(new Cardapio("@drawable/ovomelenium","Ovo Melenium", "R$10,00"));
        dadosCardapio.add(new Cardapio("@drawable/camaraoasalsa","Camarão a Salsa", "R$25,00"));
        dadosCardapio.add(new Cardapio("@drawable/rosbife","Rosbife", "R$20,00"));


        recyclerView = findViewById(R.id.item); //ligação do objeto Java com o elemento de layout
        adapter = new CardapioAdapter(this, dadosCardapio);
        //Vincular o adapter ao RecyclerView
        recyclerView.setAdapter(adapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

    }

    public void addCardapio(View v){
        dadosCardapio.add(new Cardapio("Macarrão", "R$19,00"));
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N){
            Collections.sort(dadosCardapio, Comparator.comparing(Cardapio::getComida));
        }
        //Notificar o adapter que houve uma atualização dos dados
        adapter.notifyDataSetChanged();
    }
}