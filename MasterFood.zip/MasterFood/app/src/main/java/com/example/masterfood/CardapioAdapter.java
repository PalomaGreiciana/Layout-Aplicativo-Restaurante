package com.example.masterfood;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CardapioAdapter extends RecyclerView.Adapter<CardapioAdapter.CardapioViewHolder>{

    LayoutInflater layout;
    ArrayList<Cardapio> listaCardapio;

    public CardapioAdapter (Context context, ArrayList<Cardapio>cardapio){
        layout = LayoutInflater.from(context);
        listaCardapio = cardapio;
    }

    @Override
    public CardapioViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemLista = layout.inflate(R.layout.item, parent, false);
        CardapioViewHolder viewHolder = new CardapioViewHolder(itemLista);
        return viewHolder;
    }

    //Vincula o dado com o elemento da lista
    @Override
    public void onBindViewHolder(CardapioViewHolder viewHolder, int posicao){
        viewHolder.imagem.setImageDrawable(listaCardapio.);
        viewHolder.comida.setText(listaCardapio.get(posicao).getComida());
        viewHolder.preco.setText(listaCardapio.get(posicao).getPreco());
    }

    @Override
    public int getItemCount(){
        return this.listaCardapio.size();
    }

    //Representa cada item da lista, associando o layout com o dado a ser exibido
    class CardapioViewHolder extends RecyclerView.ViewHolder{
        ImageView imagem;
        TextView comida, preco;
        public CardapioViewHolder(View layoutItem){
            super(layoutItem);
            imagem = layoutItem.findViewById(R.id.imagem);
            comida = layoutItem.findViewById(R.id.comida);
            preco = layoutItem.findViewById(R.id.preco);
        }
    }

}
